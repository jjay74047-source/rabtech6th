const API = "http://localhost:8080/api/patients";
let patients = [];
let editingId = null;

const $ = (id) => document.getElementById(id);
const rows = $("patientRows");
const dialog = $("patientDialog");
const form = $("patientForm");

$("today").textContent = new Date().toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });

async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const data = await response.json();
      message = data.message || message;
      if (data.fieldErrors) message += ": " + Object.values(data.fieldErrors).join(", ");
    } catch (_) {}
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}

function showMessage(message, isError = false) {
  const el = $("message");
  el.textContent = message;
  el.className = "message" + (isError ? " error" : "");
  window.setTimeout(() => el.classList.add("hidden"), 4500);
}

function initials(name) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

function render() {
  const term = $("searchInput").value.toLowerCase().trim();
  const filtered = patients.filter(p => [p.fullName, p.email, p.department, p.status]
    .some(v => String(v || "").toLowerCase().includes(term)));
  $("totalPatients").textContent = patients.length;
  $("totalDepartments").textContent = new Set(patients.map(p => p.department)).size;
  $("checkedIn").textContent = patients.filter(p => p.status === "Checked In").length;
  $("recordCount").textContent = `Showing ${filtered.length} of ${patients.length} records`;

  if (!filtered.length) {
    rows.innerHTML = `<tr><td colspan="5">${patients.length ? "No patients match your search." : "No patient records yet. Add your first patient."}</td></tr>`;
    return;
  }

  rows.innerHTML = filtered.map(p => {
    const statusClass = p.status.toLowerCase().replace(/\s+/g, "-");
    return `<tr>
      <td><div class="patient-name"><span class="patient-avatar">${escapeHtml(initials(p.fullName))}</span><div>${escapeHtml(p.fullName)}<div class="patient-email">${escapeHtml(p.email)}</div></div></div></td>
      <td>${escapeHtml(p.department)}</td><td>${p.age}</td>
      <td><span class="status ${statusClass}">${escapeHtml(p.status)}</span></td>
      <td><button class="action-btn" data-edit="${p.id}">Edit</button><button class="action-btn delete" data-delete="${p.id}">Delete</button></td>
    </tr>`;
  }).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}

async function loadPatients() {
  try {
    patients = await apiRequest(API);
    $("apiStatus").textContent = "API connected";
    document.querySelector(".api-status").classList.add("online");
    render();
  } catch (error) {
    $("apiStatus").textContent = "API offline";
    document.querySelector(".api-status").classList.remove("online");
    rows.innerHTML = `<tr><td colspan="5">Could not connect to the backend. Start Spring Boot on port 8080 and refresh.</td></tr>`;
    $("recordCount").textContent = "API connection required";
    showMessage(error.message, true);
  }
}

function openCreate() {
  editingId = null;
  form.reset();
  $("dialogTitle").textContent = "Add patient";
  $("formError").textContent = "";
  dialog.showModal();
}
function openEdit(id) {
  const p = patients.find(item => item.id === id);
  if (!p) return;
  editingId = id;
  form.elements.fullName.value = p.fullName;
  form.elements.email.value = p.email;
  form.elements.department.value = p.department;
  form.elements.age.value = p.age;
  form.elements.status.value = p.status;
  $("dialogTitle").textContent = "Edit patient";
  $("formError").textContent = "";
  dialog.showModal();
}

$("addPatientBtn").addEventListener("click", openCreate);
$("closeDialog").addEventListener("click", () => dialog.close());
$("cancelDialog").addEventListener("click", () => dialog.close());
$("refreshBtn").addEventListener("click", loadPatients);
$("searchInput").addEventListener("input", render);
$("dashboardNav").addEventListener("click", () => { $("dashboardNav").classList.add("active"); $("patientsNav").classList.remove("active"); window.scrollTo({top: 0, behavior: "smooth"}); });
$("patientsNav").addEventListener("click", () => { $("patientsNav").classList.add("active"); $("dashboardNav").classList.remove("active"); document.querySelector(".panel").scrollIntoView({behavior:"smooth"}); });

rows.addEventListener("click", async (event) => {
  const editButton = event.target.closest("[data-edit]");
  const deleteButton = event.target.closest("[data-delete]");
  if (editButton) openEdit(Number(editButton.dataset.edit));
  if (deleteButton) {
    const id = Number(deleteButton.dataset.delete);
    const patient = patients.find(p => p.id === id);
    if (!patient || !confirm(`Delete ${patient.fullName}'s record?`)) return;
    try {
      await apiRequest(`${API}/${id}`, { method: "DELETE" });
      showMessage("Patient record deleted.");
      await loadPatients();
    } catch (error) { showMessage(error.message, true); }
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  $("formError").textContent = "";
  const payload = {
    fullName: form.elements.fullName.value.trim(),
    email: form.elements.email.value.trim(),
    department: form.elements.department.value,
    age: Number(form.elements.age.value),
    status: form.elements.status.value
  };
  try {
    if (editingId) {
      await apiRequest(`${API}/${editingId}`, { method: "PUT", body: JSON.stringify(payload) });
      showMessage("Patient record updated successfully.");
    } else {
      await apiRequest(API, { method: "POST", body: JSON.stringify(payload) });
      showMessage("Patient added successfully.");
    }
    dialog.close();
    await loadPatients();
  } catch (error) {
    $("formError").textContent = error.message;
  }
});

loadPatients();
