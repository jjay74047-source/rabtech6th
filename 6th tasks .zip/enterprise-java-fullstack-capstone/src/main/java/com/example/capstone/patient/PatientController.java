package com.example.capstone.patient;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5500"})
public class PatientController {
    private final PatientService service;
    public PatientController(PatientService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "List all patients")
    public List<Patient> all() { return service.findAll(); }

    @GetMapping("/{id}")
    @Operation(summary = "Get a patient by ID")
    public Patient one(@PathVariable Long id) { return service.findById(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Create a patient")
    public Patient create(@Valid @RequestBody Patient patient) { return service.create(patient); }

    @PutMapping("/{id}")
    @Operation(summary = "Update a patient")
    public Patient update(@PathVariable Long id, @Valid @RequestBody Patient patient) {
        return service.update(id, patient);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Delete a patient")
    public void delete(@PathVariable Long id) { service.delete(id); }
}
