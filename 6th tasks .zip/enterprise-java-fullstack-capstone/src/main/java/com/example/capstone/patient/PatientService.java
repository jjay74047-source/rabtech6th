package com.example.capstone.patient;

import com.example.capstone.common.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class PatientService {
    private final Map<Long, Patient> patients = new ConcurrentHashMap<>();
    private final AtomicLong ids = new AtomicLong();

    public PatientService() {
        create(new Patient(null, "Aarav Sharma", "aarav@example.com", "Cardiology", 34, "Scheduled"));
        create(new Patient(null, "Meera Patil", "meera@example.com", "Neurology", 28, "Checked In"));
        create(new Patient(null, "Rohan Deshmukh", "rohan@example.com", "Orthopedics", 46, "Completed"));
    }

    public List<Patient> findAll() {
        return patients.values().stream().sorted(Comparator.comparing(Patient::getId)).toList();
    }
    public Patient findById(Long id) {
        Patient patient = patients.get(id);
        if (patient == null) throw new ResourceNotFoundException("Patient with id " + id + " was not found");
        return patient;
    }
    public Patient create(Patient patient) {
        long id = ids.incrementAndGet();
        patient.setId(id);
        if (patient.getStatus() == null || patient.getStatus().isBlank()) patient.setStatus("Scheduled");
        patients.put(id, patient);
        return patient;
    }
    public Patient update(Long id, Patient input) {
        findById(id);
        input.setId(id);
        if (input.getStatus() == null || input.getStatus().isBlank()) input.setStatus("Scheduled");
        patients.put(id, input);
        return input;
    }
    public void delete(Long id) {
        if (patients.remove(id) == null) throw new ResourceNotFoundException("Patient with id " + id + " was not found");
    }
}
