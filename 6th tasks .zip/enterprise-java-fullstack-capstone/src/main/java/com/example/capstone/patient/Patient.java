package com.example.capstone.patient;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PositiveOrZero;

public class Patient {
    private Long id;
    @NotBlank private String fullName;
    @NotBlank @Email private String email;
    @NotBlank private String department;
    @PositiveOrZero private int age;
    private String status;

    public Patient() {}
    public Patient(Long id, String fullName, String email, String department, int age, String status) {
        this.id = id; this.fullName = fullName; this.email = email;
        this.department = department; this.age = age; this.status = status;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
