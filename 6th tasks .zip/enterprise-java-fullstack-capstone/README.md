# Enterprise Java Full Stack Capstone — EnterpriseCare

A responsive Hospital Management dashboard connected to a Spring Boot REST API. This educational capstone demonstrates a layered Java backend, frontend-to-backend integration, CRUD operations, validation, global exception handling, and Swagger/OpenAPI documentation.

## Features
- Responsive HTML5/CSS/JavaScript frontend.
- Patient directory with search, create, edit, and delete.
- Spring Boot REST API with in-memory demo data (records reset when the server restarts).
- Validation using Jakarta Bean Validation.
- Centralized JSON error responses using `@RestControllerAdvice`, `@ExceptionHandler`.
- OpenAPI docs via Springdoc at `/swagger-ui.html`.
- No database or Node installation is needed for this version.

## Architecture
```text
Browser (HTML/CSS/JS :5500 or file preview)
           |
           | HTTP JSON / Fetch
           v
Spring Boot REST Controllers (:8080)
           |
           v
PatientService (demo in-memory store)
           |
           +--> GlobalExceptionHandler
           +--> Springdoc OpenAPI / Swagger UI
```

## Requirements
- JDK 17 or newer
- Maven 3.8+
- VS Code
- Optional: VS Code Live Server extension for serving the frontend

## Run the backend
Open a terminal in the root folder (the one containing `pom.xml`) and run:
```powershell
mvn spring-boot:run
```
Backend: `http://localhost:8080`

Swagger UI: `http://localhost:8080/swagger-ui.html`
OpenAPI JSON: `http://localhost:8080/v3/api-docs`

## Run the frontend
Open `frontend/index.html` with VS Code Live Server (recommended, commonly port 5500), or use another static web server. The API allows `http://localhost:5500` and `http://localhost:5173` through CORS.
The backend must be running for patient data and CRUD operations to work.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/patients` | List patients |
| GET | `/api/patients/{id}` | Get patient |
| POST | `/api/patients` | Create patient |
| PUT | `/api/patients/{id}` | Update patient |
| DELETE | `/api/patients/{id}` | Delete patient |

### Example create request
`POST http://localhost:8080/api/patients`
```json
{
  "fullName": "Priya Shah",
  "email": "priya@example.com",
  "department": "Cardiology",
  "age": 24,
  "status": "Scheduled"
}
```

## Error response example
A missing patient ID returns HTTP 404:
```json
{
  "timestamp": "2026-10-28T12:00:00Z",
  "status": 404,
  "error": "Not Found",
  "message": "Patient with id 999 was not found"
}
```
Invalid input returns HTTP 400 with field-level validation messages.

## Demo limitations and production notes
This is a portfolio/learning prototype, not a real hospital system. It has no login/authentication, uses in-memory records, and contains sample data only. Do not use real patient data. For production, add authentication/authorization, a persistent database, audit logging, HTTPS, and privacy/security review.

## GitHub submission
Suggested repository: `enterprise-java-fullstack-capstone`
Include a video walkthrough or host the frontend/backend on a suitable platform before claiming a live demo. Never publish secrets or real patient data.
